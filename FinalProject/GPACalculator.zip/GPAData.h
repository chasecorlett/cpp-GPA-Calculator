//
// Created by Chase on 8/11/2020.
//

#ifndef FINALPROJECT_GPADATA_H
#define FINALPROJECT_GPADATA_H

// declare a struct for vectors used in calculations
struct GPAData {
    double classGrade;
    double classWeight;
};


#endif //FINALPROJECT_GPADATA_H
